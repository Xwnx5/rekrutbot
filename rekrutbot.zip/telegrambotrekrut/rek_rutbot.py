
from aiogram.utils import executor
from create_bot import dp, bot
from handlers import client, admin

admin.register_admin_handler(dp)

executor.start_polling(dp, skip_updates=True)