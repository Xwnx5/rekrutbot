from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
import os
from aiogram.contrib.fsm_storage.memory import MemoryStorage

storage = MemoryStorage()

bot = Bot(token=os.getenv('TOKEN')) #здесь запускается с помощью Bash скрипта, но можно указать токен напрямую
dp = Dispatcher(bot, storage=storage)