from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from create_bot import Dispatcher, bot
from aiogram import types

class FSMAdmin(StatesGroup):
    waiting_for_year = State()
    waiting_for_initial = State()
    waiting_for_skills = State()
    waiting_for_defend = State()
    waiting_for_message_contact_handler = State()
    
async def echo_send(message: types.Message):
    if message.text == 'Привет': 
        await message.answer('И тебе привет')
    else:
        await message.answer('Я бот и я не знаю эту команду')

#@dp.message_handler(commands='start')
async def on_start_test(message: types.Message):
    await message.answer('Вопрос №1\nСколько вам лет?\nНапишите ответ (только число)')

    await FSMAdmin.waiting_for_year.set()

#@dp.message_handler(state=FSMAdmin.waiting_for_year)
async def initial(message: types.Message, state: FSMContext):
    await message.answer(text="Вопрос №2\nВведите фамилию и имя")

    global first_ans
    first_ans=message.text

    await FSMAdmin.next()

#@dp.message_handler(state=FSMAdmin.waiting_for_initial)
async def skills(message: types.Message, state: FSMContext):
    await message.answer(text='Опишите свои навыки и знания в программировании:')

    global second_ans
    second_ans = message.text

    await FSMAdmin.next()

#@dp.message_handler(state=FSMAdmin.end)
async def defend(message: types.Message, state: FSMContext):
    global third_ans
    third_ans=message.text

    global ansstr
    ansstr = 'Ваши ответы:\nВозраст:\t'+str(first_ans)+'\nИмя и фамилия:\t'+str(second_ans)+'\nВаши навыки в программировании:\t'+str(third_ans)

    await bot.send_message(chat_id=message.from_user.id, text=ansstr)

    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button_1 = types.KeyboardButton(text='Отослать свой контакт', request_contact=True)
    keyboard.add(button_1)

    await message.answer(text='Вы всё правильно заполнили? По нажатию кнопки бот перешлёт ваш контакт и ваши ответы нашему рекрутёру для дальнейшей связи с вами. Если хотите что-то изменить, то пропишите команду /start и заполните заново.', reply_markup=keyboard)

    await FSMAdmin.next()
    
#@dp.message_handler(state=FSMAdmin.defend)
async def contact(message: types.Message, state: FSMContext):
    await message.answer('Ваши ответы и контакт отправлены нашим рекрутёрам, спасибо! Ожидайте, вам напишут!', reply_markup=types.ReplyKeyboardRemove())

    admin_ids = [{}]#здесь должны быть id рекрутёров

    for i in admin_ids:
        await bot.send_message(chat_id= i , text=ansstr)
        await message.send_copy(chat_id=i)

    await state.finish()

#закоментировал все декораторы, так как есть функция ниже
def register_admin_handler(dp: Dispatcher):
    dp.register_message_handler(on_start_test, commands='start', state='*')
    dp.register_message_handler(initial, state=FSMAdmin.waiting_for_year)
    dp.register_message_handler(skills, state=FSMAdmin.waiting_for_initial)
    dp.register_message_handler(defend, state=FSMAdmin.waiting_for_skills)
    dp.register_message_handler(contact, state=FSMAdmin.waiting_for_defend, content_types=['contact'])